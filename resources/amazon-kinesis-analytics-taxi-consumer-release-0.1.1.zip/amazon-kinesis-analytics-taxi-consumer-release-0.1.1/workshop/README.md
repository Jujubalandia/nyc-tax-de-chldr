﻿# Streaming Analytics Workshop

The workshop now lives in it own GitHub repo and website:

https://streaming-analytics.labgui.de/

https://github.com/aws-samples/streaming-analytics-workshop
